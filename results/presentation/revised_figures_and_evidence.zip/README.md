# Supervisor data round — completed full run

Current presentation: `cognitive_tools_supervisor_data_round_7_slides.pptx` and the matching PDF.

Seven slides cover the research questions, mechanism, completed design, perception, collective organization, ecological outcomes, and supervisor feedback. The presentation replaces the pilot narrative with reviewed full-run results while retaining the original style.

- Presenter notes: `presenter_notes.md` (also embedded in PowerPoint).
- Current figures: `figures/full_run/` (PNG, PDF and SVG).
- Source tables: `data/full_run/`.
- Previews: `review/contact_sheet.png`; Canva: `review/canva/contact_sheet.png`.
- Reproduction: `build_data_round.py` delegates to `build_full_run_data_round.py`.
- Provenance and rationale: `data_audit.json`, `figure_review.md`.
- Prior files: `archive/pilot_v1_before_full_run_revision/`.

Local files use the same content and data as the Canva draft; they are not downloads exported from Canva. Canva save status and link are recorded in `canva_status.json`.
