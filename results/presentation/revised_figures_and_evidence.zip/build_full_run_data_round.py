"""Replace the archived pilot presentation with the reviewed full-run data round."""
from pathlib import Path
import json
import shutil
import hashlib

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from pptx import Presentation
from pptx.util import Pt, Inches
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'results/presentation'
ARCHIVE = OUT/'archive/pilot_v1_before_full_run_revision'
SOURCE = ROOT/'results/q_learning_baseline/social_analysis/ecology_perception_parallel_v1_analysis/data'
FIG = OUT/'figures/full_run'
FIG.mkdir(parents=True, exist_ok=True)
PRIMARY = pd.read_csv(SOURCE/'primary_window_summary.csv')
OUTCOME = pd.read_csv(SOURCE/'outcome_summary.csv')
CONTRAST = pd.read_csv(SOURCE/'planned_contrast_summary.csv')
PREFIX = 'ecology_perception_parallel_v1_'
RUNS = ['b0','s1','s2','r1_mu010','r0_r1_mu010','r2_mu010','r0_r2_mu010','r3_mu010','r0_r3_mu010']
LABELS = ['B0 · no social input','S1 · fixed random','S2 · scale-free','Adaptive local','Matched local','Adaptive mixed','Matched mixed','Adaptive global','Matched global']
SCENARIOS = ['uniform_high','patchy_high','split_high_low']
COLORS = ['#247BA0','#BD6C18','#8B5094']
NAMES = ['Uniform high','Patchy high','Split high / low']
plt.rcParams.update({'font.family':'Liberation Sans','font.size':16,'axes.spines.top':False,
    'axes.spines.right':False,'axes.spines.left':False,'axes.edgecolor':'#999999',
    'text.color':'#222222','axes.labelcolor':'#444444','xtick.color':'#666666',
    'ytick.color':'#444444','pdf.fonttype':42,'svg.fonttype':'none'})

def plot(name, table, measures, include_b0=True):
    fig, axes = plt.subplots(1,len(measures),figsize=(16,5.7),squeeze=False)
    fig.subplots_adjust(left=.19,right=.985,top=.83,bottom=.16,wspace=.32)
    runs=RUNS if include_b0 else RUNS[1:]
    labels=LABELS if include_b0 else LABELS[1:]
    for col,(metric,scale,title,limits) in enumerate(measures):
        ax=axes[0,col]
        for j,(eco,color,marker) in enumerate(zip(SCENARIOS,COLORS,['o','s','^'])):
            d=table[(table.scenario==eco)&(table.metric==metric)].set_index('run_id')
            for i,run in enumerate(runs):
                if PREFIX+run not in d.index: continue
                r=d.loc[PREFIX+run]
                mean,lo,hi=np.array([r['mean'],r.bootstrap_ci_low,r.bootstrap_ci_high])*scale
                assert limits[0]<=lo<=mean<=hi<=limits[1]
                ax.errorbar(mean,i+(j-1)*.20,xerr=[[mean-lo],[hi-mean]],fmt=marker,
                            color=color,ms=6,capsize=2,lw=1.5)
        ax.set(ylim=(len(runs)-.5,-.6),xlim=limits,yticks=range(len(runs)),xlabel=title)
        ax.set_yticklabels(labels if col==0 else [])
        ax.tick_params(axis='y',length=0)
        ax.grid(axis='x',color='#E7E7E7');ax.set_axisbelow(True)
    fig.legend(handles=[Line2D([0],[0],color=c,marker=m,label=n,lw=1.5)
                        for c,m,n in zip(COLORS,['o','s','^'],NAMES)],
               loc='upper center',bbox_to_anchor=(.60,.98),ncol=3,frameon=False,fontsize=17)
    for ext in ['png','pdf','svg']:fig.savefig(FIG/f'{name}.{ext}',dpi=200,facecolor='white')
    plt.close(fig)

plot('perception',PRIMARY,[
    ('social_perception_error',100,'Mean absolute error (pp)',(15,24)),
    ('majority_mismatch_rate',100,'Mismatch among non-ties (%)',(7,20)),
    ('majority_tie_rate',100,'Tied comparisons (%)',(19,30))],False)
plot('organization',PRIMARY,[
    ('visibility_gini',1,'Visibility Gini (0–1)',(.20,.45)),
    ('low_extraction_rate',100,'Low-extraction share (%)',(23,35))])
plot('outcomes',OUTCOME,[
    ('eval_mean_mean_resource_fraction',100,'Resource / capacity (%)',(9,15)),
    ('eval_mean_mean_reserve_welfare',100,'Reserve welfare (%)',(60,82)),
    ('final_wealth_gini',1,'Final wealth Gini (0–1)',(.40,.65))])

# Each replacement keeps the existing paragraph structure for a parallel Canva edit.
changes={
1:{
0:'How does ecology shape perception and collective organization?',
3:'RQ1: When do local observations misrepresent population behavior?\nRQ2: How do ecology and observation rules organize the population?',
6:'Local perception',7:'What do selected peers do?\nHow representative is that view?',
10:'Collective organization',11:'Who becomes visible?\nWhich actions become common?',
14:'Consequences',15:'Resource condition\nWelfare and inequality',
18:'FROZEN HYPOTHESES',
19:'H1: perception varies with ecology. H2: local search concentrates visibility.\nH3: adaptive selection changes perception relative to matched random turnover.'},
2:{
0:'Population information feeds decisions about local resources',
1:'Agents stay in place; information links change. Population accuracy may not imply local usefulness.',
37:'Reward = own harvest. Welfare is measured separately; it does not enter the reward.'},
3:{
0:'The full run separates ecology, search scope and observer selection',
1:'27 conditions × 100 replicates = 2,700 condition-replicates · 64 agents per population',
10:'Uneven visibility + varying attention',
13:'Local / mixed / global search\nSame rewiring event counts and scope\nDifferent selection of observers',
21:'Illustrative capacity maps · common scale 0–1',
22:'3 ecologies × 9 observation rules\n100 replicates per condition\n5,000 training + 1,000 evaluation steps\nOutcomes: fresh reset, frozen policies + graphs'},
4:{
0:'Observation rules change perception; ecology differences are small',
1:'Final 1,000 training steps · all eight social treatments · means and 95% bootstrap intervals',
5:'Adaptive selection lowers non-tie mismatch by 1.35–2.16 pp versus matched turnover.',
6:'Raw error includes sampling: four random peers already imply 17.5–17.8 pp MAE. S2 also varies attention capacity.'},
5:{
0:'Local search concentrates visibility, even under random turnover',
1:'Collective organization = visibility concentration and prevalence of low-extraction behavior',
5:'Local versus global search: +0.116–0.123 visibility Gini under adaptive rewiring.',
6:'Matched random turnover produces a similar gap. All nine adaptive–matched extraction CIs include zero.\n100 replicates; final 1,000 training steps; pointwise 95% bootstrap CIs. “Local” means social-graph proximity.'},
6:{
0:'Ecology changes welfare and inequality; adaptive benefits are inconsistent',
1:'Absolute outcomes · 1,000-step fresh-reset evaluation · frozen policies and terminal networks',
5:'Split versus uniform: welfare −9.5 to −11.9 pp; wealth Gini +0.169 to +0.175.',
6:'Adaptive–matched welfare: only 1 of 9 pointwise CIs excludes zero. Split changes several ecological parameters together.\nReset matters: mean reserve welfare is 72% after reset versus 26% in continuation. This is not long-run sustainability.'},
7:{
0:'The next question is when information becomes useful for decisions',
1:'Completed study: ecology → population perception and organization → material consequences',
6:'What the run establishes',
7:'Observation rules shift\nperception and concentration.\n\nEcology shifts welfare\nand wealth inequality.',
10:'What remains unresolved',
11:'Better population estimates\ndo not consistently improve\n\nlocal decisions or welfare.\nThe causal link is untested.',
14:'One bounded next study',
15:'One Harvest environment;\nfixed learner and attention.\n\nInformative versus shuffled\nsignals; matched productivity.',
16:'Feedback I want from you',
17:'Are RQ1 and RQ2 clear, and do these measures capture collective organization?\nShould the next hypothesis target decision usefulness rather than global accuracy?\nWould SocialJax Commons Harvest justify migration, or should we retain this model?'},
}
notes=[
'Purpose: obtain supervisor feedback on the clarity of the research questions, hypotheses and project structure. These are the confirmed frozen hypotheses in docs/ideas/ecology-perception-organization.md, not the older pilot hypothesis of a necessary sustainability improvement. H1 is nondirectional. H2 was informed by related work and the pilot. H3 predicts a difference, not necessarily an improvement. Collective organization means measurable population patterns, not conscious coordination. Secondary consequences are resource condition, reserve welfare and accumulated-harvest inequality.',
'The schematic describes the feedback, not every implementation step. Agents observe previous source actions alongside local resource/capacity, choose extraction with independent tabular Q-learning, experience resource renewal, compare expected versus observed peer actions and may replace information sources. Surprise selects observers; removed and replacement sources are random conditional on the search rule. Local replacement is sources-of-sources in the information graph, not geographical proximity. Reward is realized harvest. Stationary locations, proportional allocation under scarcity and a 3×3 state representation restrict the behavioral mechanism. The review found 97.1% scarce-state occupancy in fresh-reset evaluation, 99.7% in continuation. These are diagnostics, not causal proof of a representation failure.',
'Full campaign ecology_perception_parallel_v1, source commit 2ac3a887f271874d9ff71726a3d0ed9e83601efc. Nine treatments: B0, S1, S2, R1/R2/R3 and their three matched R0 controls. Three ecologies, N=64, 100 replicates each, 5000 training and 1000 evaluation steps. Primary perception and organization outcomes average the 20 recorded checkpoints in 4000<t≤5000 within replicate. Secondary outcomes use fresh-reset evaluation with frozen policies and terminal networks. R0 matches event counts and search scope, identifying observer selection conditional on the adaptive schedule. S2 changes attention capacity too. Maps are illustrative seed-42 capacity maps from the same scenario definitions, not observations from the full-run replicates. Split bundles changes in capacity, regeneration, equilibrium and spatial arrangement.',
'Figure uses primary_window_summary.csv, all eight social treatments and all ecologies. Error is the absolute difference between observed low-extraction fraction and prevalence among the other 63 agents. Mismatch excludes ties; tied comparisons are shown separately. S2−S1 error is +4.07 to +4.26 pp, but attention varies. Across ecology/scope pairs, adaptive−matched mismatch is −1.35 to −2.16 pp; all nine pointwise intervals exclude zero. MAE improves by 0.095 to 0.443 pp; seven of nine intervals exclude zero. Tie rates generally decrease too. The post-hoc exact hypergeometric four-peer baseline is 17.55–17.81 pp; fixed-attention observed-minus-baseline means range −0.273 to +0.210 pp. This diagnostic conditions on current population actions and is not a counterfactual training run. It excludes variable-attention S2. Reference: Lerman et al., The Majority Illusion in Social Networks, https://arxiv.org/abs/1506.03022. Complete paired results and sampling figures are in results/review/full_run_2026-09-29/.',
'Figure uses primary_window_summary.csv. Display all nine treatments; B0 has no observation network and therefore no visibility-Gini point. Adaptive local−global visibility Gini is +0.116 to +0.123 across ecologies; matched random local−global is +0.114 to +0.123. This supports the scope prediction, not attribution of concentration to the surprise trigger. All nine adaptive−matched low-extraction intervals and visibility-Gini intervals include zero. This is not an equivalence conclusion. All figures use 100 independent replicates per condition, not agents as independent samples. Bootstrap intervals are pointwise percentile intervals from 5000 resamples, without multiplicity adjustment. Zoomed axes are deliberate.',
'Figure uses outcome_summary.csv, all nine treatments and all three ecologies. Across eight social treatments, split−uniform welfare is −9.49 to −11.92 percentage points and wealth Gini +0.169 to +0.175. These are ranges of treatment-specific effects, not confidence intervals or pooled effects. Resource metric is mean local R/K, not total stock; a larger normalized fraction does not imply a richer ecology. R0 paired effects: all nine wealth-Gini intervals include zero, eight of nine welfare and eight of nine resource intervals include zero. The isolated positive intervals are unadjusted and do not establish broad benefit. The 72.3% fresh-reset versus 26.2% continuation welfare diagnostic equally weights 27 condition means. Reset restores ecology and full initial energy; it is not a pure energy intervention. Neither 1000-step evaluation establishes long-run sustainability. Existing values/paired means were independently checked against raw tables in the review.',
'Close by separating conclusions from proposed future work. No migration or new simulation has been undertaken. Prospective hypothesis: information improves outcomes when it predicts ecological consequences relevant to the observer; population representativeness alone may be insufficient. A constrained option is one Commons Harvest substrate, one learner, two productivity-matched arrangements and informative versus shuffled social signals with equal attention. Define behavior over a fixed opportunity-aware window: inactivity in a movement/harvesting environment is not automatically cooperation. SocialJax offers GPU-oriented Harvest and IPPO/MAPPO baselines: https://github.com/cooperativex/SocialJax. Melting Pot is the benchmark-provenance alternative: https://github.com/google-deepmind/meltingpot. The older sequential_social_dilemma_games repository explicitly recommends Melting Pot. These are candidates, not locally benchmarked migration commitments. Full review: docs/reviews/full-run-review-2026-09-29.md. Ask the supervisor to select the scientific direction before adding mechanisms.'
]

prs=Presentation(ARCHIVE/'cognitive_tools_supervisor_data_round_7_slides.pptx')
canva_changes=[]
for number, slide in enumerate(prs.slides,1):
    for shape in slide.shapes:
        if shape.has_text_frame and 'PILOT v1' in shape.text:
            shape.text_frame.paragraphs[0].runs[0].text=shape.text.replace('PILOT v1','FULL RUN · SEPTEMBER 2026')
    for index,value in changes[number].items():
        shape=slide.shapes[index]
        old=shape.text.split('\n');new=value.split('\n')
        old_nonempty=[x for x in old if x];new_nonempty=[x for x in new if x]
        assert len(old_nonempty)==len(new_nonempty),(number,index,old,new)
        canva_changes.extend({'page':number,'old':a,'new':b} for a,b in zip(old_nonempty,new_nonempty))
        for paragraph,line in zip(shape.text_frame.paragraphs,new):
            if paragraph.runs:
                paragraph.runs[0].text=line
                for r in list(paragraph.runs)[1:]:r.text=''
            else:paragraph.text=line
        # Keep revised text legible and within the original grid.
        size=38 if index==0 else None
        if number==1 and index==3:size=31
        if number==1 and index==19:size=27
        if number==1 and index==18:shape.width=Inches(6);size=21
        if number==2 and index==37:size=21
        if number==3 and index==22:size=25
        if number in [4,5,6] and index==5:size=27
        if number in [4,5,6] and index in [6,7]:size=19
        if number==7 and index==17:size=25
        if size:
            for p in shape.text_frame.paragraphs:
                p.font.size=Pt(size)
                for r in p.runs:r.font.size=Pt(size)
    # Smaller node headings preserve the reference style without wrapping.
    for idx in ({1:[6,10,14],2:[17,21,25,29],7:[6,10,14]}.get(number,[])):
        for p in slide.shapes[idx].text_frame.paragraphs:
            p.font.size=Pt(26)
            for r in p.runs:r.font.size=Pt(26)
    if number in [4,5,6]:
        old_picture=slide.shapes[4]
        old_picture._element.getparent().remove(old_picture._element)
        path=FIG/({4:'perception',5:'organization',6:'outcomes'}[number]+'.png')
        slide.shapes.add_picture(str(path), Inches(.5), Inches(2.60), width=Inches(19),height=Inches(6.77))
        # Bottom text sits below the plot rather than over its x-axis labels.
        for shape in slide.shapes:
            if shape.has_text_frame and shape.text==changes[number][5]:shape.top=Inches(9.25)
            if shape.has_text_frame and shape.text==changes[number][6]:shape.top=Inches(9.92)
    slide.notes_slide.notes_text_frame.text=notes[number-1]

assert len(prs.slides)==7
prs.core_properties.title='Ecology, Perception and Collective Organization — Full-run Data Round'
prs.core_properties.subject='Seven-slide supervisor presentation of the completed ecology_perception_parallel_v1 campaign'
dest=OUT/'cognitive_tools_supervisor_data_round_7_slides.pptx'
prs.save(dest)
(OUT/'canva_text_changes.json').write_text(json.dumps(canva_changes,indent=2))
(OUT/'presenter_notes.md').write_text('# Supervisor data round — completed full run\n\n'+ '\n\n'.join(f'## Slide {i+1}\n\n{t}' for i,t in enumerate(notes))+'\n')
data=OUT/'data/full_run';data.mkdir(parents=True,exist_ok=True)
for name in ['primary_window_summary.csv','outcome_summary.csv','planned_contrast_summary.csv']:
    shutil.copy2(SOURCE/name,data/name)
audit={'campaign':'ecology_perception_parallel_v1','slides':7,'conditions':27,'replicates_per_condition':100,
       'source_commit':'2ac3a887f271874d9ff71726a3d0ed9e83601efc','review':'docs/reviews/full-run-review-2026-09-29.md',
       'plot_source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in data.glob('*.csv')},
       'backup':str(ARCHIVE.relative_to(ROOT)), 'no_simulation_changes':True}
(OUT/'data_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(dest)
